# FAT32-Interpreter

[Link to GitHub](https://github.com/WTsaur/FAT32-Interpreter.git)

# Contributions By Member

## Nicholas Tidwell
* makefile
* implemented 'ls'
* implemented 'cd'
* implemented 'creat'
* implemented 'mkdir'
* implemented 'rm'
* implemented 'open'
* implemented 'close'
* implemented 'read'
* implemented 'lseek'

## William Tsaur
* README.md
* DIRENTRY.h
* BPB.h
* makefile
* implemented 'info'
* implemented 'exit'
* implemented 'ls'
* implemented 'cd'
* implemented 'size'

## Michael Styron
* implemented 'cp'
* implemented 'mv'
* testing
* bug fixes

# Notes:
* mv command cannot move directories (instances in which FROM == a dir entry)